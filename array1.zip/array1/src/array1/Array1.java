/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array1;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Array1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        int[] list={10,20,30,40,50}; //index 0
//        System.out.println("list[0]="+list[0]);
//        System.out.println("list[0]="+list[3]);
//        int a=list[0]+list[4];
//        System.out.println("add="+a);
        Scanner input=new Scanner(System.in);
        int[] list=new int[5];
        int[] copy=new int[5];
        double[] r=new double[6];
        int total=0;
        System.out.println("enter any int value to store in array");
        for(int i=0;i<r.length;i++)
        {
            r[i]=Math.random()*5;
        }
        for(int i=0;i<list.length;i++)
        {
            list[i]=input.nextInt();
            total=total+list[i];
            copy[i]=list[i];
        }
        int max=list[0]; 
        for(int i=0;i<list.length;i++)
        {
            if(list[i]>max) 
            {
                max=list[i];
            }
            System.out.println("list["+i+"]="+list[i]);                 
        }
        for(int i=0;i<list.length;i++)
        {
            System.out.println("copy["+i+"]="+copy[i]);     
        }
        System.out.println("total of array element="+total);
        System.out.println("max value="+max);
        for(int i=0;i<r.length;i++)
        {
            System.out.println("r[i]="+r[i]);
        }
        
        
        
    }
    
}

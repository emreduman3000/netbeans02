/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array1;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class arraymethod {
    public static void main(String[] args) 
    {
        Scanner input=new Scanner(System.in);
        int[] list=new int[5];
        System.out.println("enter any int value to store in array");
        for(int i=0;i<list.length;i++)
        {
            list[i]=input.nextInt();            
        }
        for(int i=0;i<list.length;i++)
        {
            System.out.println("list["+i+"]="+list[i]);                 
        }
        System.out.println("enter value to search from array");
        int k=input.nextInt();
        int m=search(list,k);
        if(m>=0)
        {
            System.out.println("search found");
        }
        else
        {
            System.out.println("search not found");
        }
    } 
    public static int search(int[] a,int n)
    {
       for(int i=0;i<a.length;i++)
       {
           if(a[i]==n)
               return i;
       }
       return -1; 
    }
}

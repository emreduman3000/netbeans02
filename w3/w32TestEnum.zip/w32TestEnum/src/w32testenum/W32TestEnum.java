/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w32testenum;

/**
 *
 * @author kantaria
 */
public class W32TestEnum {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Currency c1=new Currency();
        
        //Currency coin=Currency.DIME; 
        //coin=2;
        
        Currency coin1=Currency.QUARTER;
        System.out.println(coin1.getValue());
        System.out.println(coin1.getDname());
        
        Currency coin3=Currency.DIME;
        System.out.println(coin3.getValue());
        System.out.println(coin3.getDname());
        
        Currency coin2=Currency.NICKLE;
        switch(coin2)
        {
            case PENNY:
                    System.out.println(coin2.getValue());
                    System.out.println(coin2.getDname());
                    break;
            case NICKLE:
                    System.out.println(coin2.getValue());
                    System.out.println(coin2.getDname());
                    break;
            case DIME:
                    System.out.println(coin2.getValue());
                    System.out.println(coin2.getDname());
                    break;
            case QUARTER:
                    System.out.println(coin2.getValue());
                    System.out.println(coin2.getDname());
                    break;
            default: System.out.println("invalid choice");                
        }
    }
    
}

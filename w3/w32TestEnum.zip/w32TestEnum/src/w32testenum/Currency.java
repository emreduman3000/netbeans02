/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w32testenum;

/**
 *
 * @author kantaria
 */
public enum Currency 
{
    PENNY(1,"penny"),
    NICKLE(5,"nickle"),
    DIME(10,"dime"),
    QUARTER(25,"quarter");
    private int value;
    private String dname;
    private Currency(int value,String dname)
    {
        this.value=value;
        this.dname=dname;
    }
    public int getValue()
    {
        return value;
    }
    public String getDname()
    {
        return dname;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w31testaccount;

import java.util.Scanner;

/**
 *
 * @author kantaria
 */
public class W31TestAccount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        System.out.println("enter balance amount");
        double b=sc.nextDouble();
        System.out.println("enter how much money to withdraw");
        double w=sc.nextDouble();
        System.out.println("enter how much money to deposit");
        double d=sc.nextDouble();
        Saving s1=new Saving(b);
        System.out.println("after withdraw final balance="+s1.withdraw(w));
        s1.setBalance(s1.withdraw(w));
        System.out.println("after deposit final balance="+s1.deposit(d));        
    }  
}

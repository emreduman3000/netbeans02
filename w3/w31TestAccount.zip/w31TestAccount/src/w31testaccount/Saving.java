/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w31testaccount;

/**
 *
 * @author kantaria
 */
public class Saving extends Account
{
    public Saving(double balance)
    {
        super(balance);
    }
    public double withdraw(double w)
    {
        return getBalance()-w;
    }
    public double deposit(double d)
    {
        return getBalance()+d;
    }    
}

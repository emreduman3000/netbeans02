/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w32testrectangle;

/**
 *
 * @author kantaria
 */
public class W32TestRectangle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Rectangle r1=new Rectangle(4,5);
        Rectangle r2=new Rectangle(2,2);
        int a=r1.compareTo(r2);
        if(a==1)
            System.out.println("r1 is bigger than r2");
        else if(a==-1)
            System.out.println("r1 is smaller than r2");
        else
            System.out.println("area of r1 and r2 is equal/same");
    }
    
}

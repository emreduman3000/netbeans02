/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w31testshape;

/**
 *
 * @author kantaria
 */
public class Circle extends Shape implements Circumference,Volume
{
    private double radius;
    public Circle(String name,double radius)
    {
        super(name);
        this.radius=radius;
    }
    public double area()
    {
        return 3.14*radius*radius;
    }  
    public double circumference()
    {
        return 2*3.14*radius;
    }
    public double volume()
    {
        return 3.14*4.0/3.0*radius*radius;
    }
    public String toString()
    {
        return "name="+getName()+" radius="+radius+" area of circle="+area()
                + " circumference of circle="+circumference()+" volume of circle="+volume();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w31testshape;

/**
 *
 * @author kantaria
 */
public abstract class Shape 
{
    private String name;
    public Shape(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }
    public void show()//non abstract method use if necessory
    {
        System.out.println("abstract shape method");
    }
    public abstract double area(); //declaration   
}











/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w31testshape;

/**
 *
 * @author kantaria
 */
public class Rectangle extends Shape
{
    private double height,width;
    public Rectangle(String name,double height,double width)
    {
        super(name);
        this.height=height;
        this.width=width;
    }
    public double area()//method body of abstract method
    {
        return height*width;
    }
    public String toString()
    {
        return "name="+getName()+" height="+height+
                " width="+width+" area of rectangle="+area();
    }
    
}

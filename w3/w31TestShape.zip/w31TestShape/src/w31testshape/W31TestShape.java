/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w31testshape;

import java.util.Scanner;

/**
 *
 * @author kantaria
 */
public class W31TestShape {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter name for your shape");
        String s1=sc.next();
        System.out.println("Enter name for your shape");
        String s2=sc.next();
        System.out.println("enter radius value");
        double r=sc.nextDouble();
        System.out.println("enter height value");
        double h=sc.nextDouble();
        System.out.println("enter width value");
        double w=sc.nextDouble();        
        Circle c1=new Circle(s1,r);        
        Rectangle r1=new Rectangle(s2,h,w);
        System.out.println(c1.toString());
        System.out.println(r1.toString());
        
        //Shape sh1=new Circle(s1,r);
        //System.out.println(sh1.toString());
    }
    
}

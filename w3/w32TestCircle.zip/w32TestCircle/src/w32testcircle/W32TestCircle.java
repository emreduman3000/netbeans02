/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w32testcircle;

/**
 *
 * @author kantaria
 */
public class W32TestCircle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Circle c1=new Circle(2);
        Circle c2=new Circle(2);
        //Circle c2=new Circle(3);
        //System.out.println(c1==c2);
        
        Circle c3=new Circle(2);
        //Circle c4=new Circle(2);
        Circle c4=new Circle(5);
        //System.out.println(c3.equals(c4));
        
        Circle c5=new Circle(2);
        Circle c6=new Circle(2);
        //Circle c6=new Circle(5);
        System.out.println(c5.equals(c6));
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w9filefxml;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author kantaria
 */
public class FXMLfileController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Button btnwrite;
    @FXML Button btnread;
    @FXML TextField txtname;
    @FXML TextField txtnw;
    @FXML TextField txthr;
    @FXML TextArea tarea;
    File myfile=new File("c:\\w9fxml.txt");
    
    @FXML
    private void write(ActionEvent event)
    {
        try
        {
            FileWriter fw=new FileWriter(myfile,true); //append mode
            PrintWriter output=new PrintWriter(fw);
            String name=txtname.getText();
            double nw=Double.parseDouble(txtnw.getText());
            double hr=Double.parseDouble(txthr.getText());
            output.println(name+","+nw+","+hr);
            output.close();
            System.out.println("file created");
        }
        catch(IOException e)
        {
            System.out.println("error in file write");
        }
    }
    @FXML
    private void read(ActionEvent event)
    {
        try
        {
            Scanner input=new Scanner(myfile); //open read mode
            while(input.hasNext())
            {
                String s=input.next();
                //System.out.println(s);
                Scanner scn=new Scanner(s);
                scn.useDelimiter(",");
                String n=scn.next();
                double w=scn.nextDouble();
                double h=scn.nextDouble();
                double sl=w*h;
                tarea.appendText("name="+n+" no of weeks="+w+" hourly rate="+h+" salary"+sl+"\n");
            }
            input.close();
        }
        catch(IOException e)
        {
            System.out.println("error in file read");
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}

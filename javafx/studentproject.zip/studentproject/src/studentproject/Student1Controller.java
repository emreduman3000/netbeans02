/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentproject;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class Student1Controller implements Initializable {
    ArrayList<student> list=new ArrayList<student>();
    static int record=0;
    PrintWriter output;
    Scanner input;
    File myfile;
    @FXML private Button add;
    @FXML private Button save;
    @FXML private Button write;
     @FXML private Button next;
      @FXML private Button previous;
       @FXML private Button edit;
    @FXML private TextField tfname;
    @FXML private TextField tlname;
    @FXML private TextField tid;
    @FXML private TextField tage;
    @FXML
    private void edit1(ActionEvent event)
    {
        save.setDisable(false);
        add.setDisable(true);
        if(record==0)
            previous.setDisable(true);
        else
            previous.setDisable(false);
        
        if(record==list.size()-1)
                next.setDisable(true);
        else
                next.setDisable(false);
    }
    @FXML
    private void previous1(ActionEvent event)
    {
        record--;
        tfname.setText(list.get(record).getFirst());
        tlname.setText(list.get(record).getFirst());
        tid.setText(String.valueOf(list.get(record).getId()));
        tage.setText(String.valueOf(list.get(record).getAge()));
        if(record==0)
            previous.setDisable(true);
        else
            previous.setDisable(false);
        
        if(record==list.size()-1)
                next.setDisable(true);
        else
                next.setDisable(false);
    }
    @FXML
    private void next1(ActionEvent event)
    {
        record++;
        tfname.setText(list.get(record).getFirst());
        tlname.setText(list.get(record).getFirst());
        tid.setText(String.valueOf(list.get(record).getId()));
        tage.setText(String.valueOf(list.get(record).getAge()));
        if(record==list.size()-1)
                next.setDisable(true);
        else
                next.setDisable(false);
        
        if(record==0)
            previous.setDisable(true);
        else
            previous.setDisable(false);
        
    }
    @FXML
    private void add1(ActionEvent event)
    {
        record=list.size();
        System.out.println("add1 record="+record+"size="+list.size());
        tfname.clear();
        tlname.clear();
        tid.clear();
        tage.clear();        
    }
    @FXML
    private void save1(ActionEvent event)
    {
        student s=new student();
        s.setFirst(tfname.getText());
        s.setLast(tlname.getText());
        s.setId(Integer.parseInt(tid.getText()));
        s.setAge(Double.parseDouble(tage.getText()));
        if(record==list.size())
        {
            list.add(s);
            System.out.println("save1 if record="+record+"size="+list.size());
        }
        else
        {
            list.set(record, s);
            System.out.println("save1 if record="+record+"size="+list.size());
        }
    }
    @FXML
    private void write1(ActionEvent event)
    {
        try
        {
            PrintWriter pr=new PrintWriter(myfile);
            System.out.println("printwiter pr empty file");
            pr.print("");
            pr.close();
            
            FileWriter fw=new FileWriter(myfile,true); //append mode
            output=new PrintWriter(fw);
            System.out.println("printwriter output append mode");
            for(int i=0;i<list.size();i++)
            {
                output.println(list.get(i).getFirst()+","+list.get(i).getLast()+","+list.get(i).getId()+","+list.get(i).getAge());
            }
            output.close();
        }
        catch(Exception e)
        {
            System.out.println("error in write1");
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      myfile=new File("c:\\student.txt"); 
      try
      {
          if(myfile.exists())
          {
//            student st=new student();
//            list.add(st);
//            System.out.println("initialize record="+record+"size="+list.size());
              input=new Scanner(myfile);
              while(input.hasNext())
              {
                  String s=input.next();
                  Scanner r=new Scanner(s);
                  r.useDelimiter(",");
                  student st=new student();
                  st.setFirst(r.next());
                  st.setLast(r.next());
                  st.setId(r.nextInt());
                  st.setAge(r.nextDouble());
                  list.add(st);
                  tfname.setText(list.get(record).getFirst());
                  tlname.setText(list.get(record).getFirst());
                  tid.setText(String.valueOf(list.get(record).getId()));
                  tage.setText(String.valueOf(list.get(record).getAge()));
              }
          }
          else
          {
              System.err.println("file not exists add record first");
          }
          input.close();
      }
      catch(Exception e)
      {
          System.out.println("error in initialize");
      }
    }    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentproject;

/**
 *
 * @author admin
 */
public class student 
{
    private String first,last;
    private int id;
    private double age;

    public student() 
    {
    }
   
    public student(String first, String last, int id, double age) {
        this.first = first;
        this.last = last;
        this.id = id;
        this.age = age;
    }

    public String getFirst() {
        return first;
    }

    public String getLast() {
        return last;
    }

    public int getId() {
        return id;
    }

    public double getAge() {
        return age;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAge(double age) {
        this.age = age;
    }
    
}

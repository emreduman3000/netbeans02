/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w9file1;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author kantaria
 */
public class W9file1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        File myfile=new File("c:\\file1.txt"); //absolute path
        File m=new File("temp.txt"); //relative path assignment project
        try
        {    
           PrintWriter output=new PrintWriter(myfile); //open write mode
           PrintWriter pw=new PrintWriter(m); //open write mode
           pw.println("this is java class");
           pw.close();
           output.println("this is java class");
           output.println("java,24178,80000");
           output.println("hello good morning");
           output.println("this;is;college");
           output.print("this is line one");
           output.print("this is line two");
           output.printf("%d %f %s",200,50.5,"java");
           output.close();
           System.out.println("file created");
        }
        catch(IOException e)
        {
            System.out.println("error in file write");
        }
        try
        {
          Scanner input=new Scanner(myfile);  //open file in read mode
          Scanner i=new Scanner(m);
          while(input.hasNext())
          {
              input.useDelimiter(",");
              System.out.println(input.next());
          }          
          input.close();
        }
        catch(IOException e)
        {
            System.out.println("error in file read");
        }        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w5testfx;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

/**
 *
 * @author kantaria
 */
public class W5TestFX extends Application{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
 
    @Override
    public void start(Stage stage) throws Exception {
       
        FlowPane fp=new FlowPane();
        fp.setAlignment(Pos.CENTER);
        Button btn1=new Button("one");
        Label lbl1=new Label("this is test application");
        TextField txt1=new TextField();
        Button btn2=new Button("two");
        Button btn3=new Button("three");
        Button btn4=new Button("four");
        Button btn5=new Button("five");
        fp.getChildren().addAll(btn1,lbl1,txt1,btn2,btn3,btn4,btn5);
        
        //Parent root = FXMLLoader.load(getClass().getResource("FXMLw5test.fxml"));
        //Scene sc=new Scene(root);
        //stage.setScene(new Scene(root));
        
        Scene sc=new Scene(fp,300,300);
        stage.setScene(sc);        
        stage.setTitle("First JAVAFX Application");
        stage.show();
    }    
}

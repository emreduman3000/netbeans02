/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testemployee;

/**
 *
 * @author kantaria
 */
public class TestEmployee {

    /**
     * @param args the command line arguments
     */
    static double count=5;
    public static void main(String[] args) {
        // TODO code application logic here
        employee e1=new employee("java",1234,40,20.5);
        System.out.println("emp name="+e1.getName());
        System.out.println("emp id="+e1.getId());
        System.out.println("emp nweek="+e1.getNweek());
        System.out.println("emp hrate="+e1.getHrate());
        System.out.println("emp salary="+e1.salary());
        System.out.println(e1.toString());
        count=count+5;
        System.out.println("count="+count);
        e1.setName("hello");
        e1.setId(7135);
        e1.setNweek(50);
        e1.setHrate(30.5);
        System.out.println("emp name="+e1.getName());
        System.out.println("emp id="+e1.getId());
        System.out.println("emp nweek="+e1.getNweek());
        System.out.println("emp hrate="+e1.getHrate());
        System.out.println("emp salary="+e1.salary());
        System.out.println(e1.toString());
        count=count+e1.getNweek();
        System.out.println("count="+count);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testemployee;

/**
 *
 * @author kantaria
 */
public class employee {
    private String name;
    private int id;
    private double nweek;
    private double hrate;
    public employee(String name,int id,double nweek,double hrate) //name="java"
    {
        this.name=name;
        this.id=id;
        this.nweek=nweek;
        this.hrate=hrate;
    }
    public String getName() //accessor or read
    {
        return name;
    }
    public int getId()
    {
        return id;
    }
    public double getNweek()
    {
        return nweek;
    }
    public double getHrate()
    {
        return hrate;
    }
    public void setName(String name) //mutatore or write
    {
        this.name=name;
    }
    public void setId(int id)
    {
        this.id=id;
    }
    public void setNweek(double nweek)
    {
        this.nweek=nweek;
    }
    public void setHrate(double hrate)
    {
        this.hrate=hrate;
    }
    public double salary()
    {
        return nweek*hrate;
    }
    public String toString()
    {
        return "name= "+name+"id "+id+"no of weeks= "+nweek+
                "hourly rate= "+hrate+"emp salary= "+salary();
    }
}

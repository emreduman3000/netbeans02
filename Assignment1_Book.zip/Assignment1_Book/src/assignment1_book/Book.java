/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1_book;

/**
 *
 * @author emreduman
 */
public class Book {
    private String BookName="java";
    private int BookQuantity=10;
    private double BookPrice=50.5d;
    
    public Book()
    {
        this.BookName=BookName;
        this.BookQuantity=BookQuantity;
        this.BookPrice=BookPrice;
    }
    
    public Book(String BookName,int BookQuantity,double BookPrice)
    {
        this.BookName=BookName;
        this.BookQuantity=BookQuantity;
        this.BookPrice=BookPrice;
    }
    
    public String getBookName()   { return BookName;} 
    
    public int getBookQuantity()  { return BookQuantity;} 
    
    public double getBookPrice()  {return BookPrice;}
    
    
    @Override
    public String toString()
    {
        return("Book Name:"+this.BookName+"\n"+"Book Qunatity:"+this.BookQuantity+"\n"+"Book Price:"+this.BookPrice);
    }
    
    public String getPrice()
    {

        String TotalPrice=Double.toString(this.BookQuantity*this.BookPrice);
        return("Total Book Price:"+TotalPrice);
    }
}


class Test extends Book
{
    public Test(String BookName,int BookQuantity,double BookPrice)
    {
        super(BookName,BookQuantity,BookPrice);
    }
    
    
    @Override
    public String toString()
    {
        return super.toString();
    }
    
    
    @Override
    public String getPrice()
    {
        return super.getPrice();
        
    }
    
}
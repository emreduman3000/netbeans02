/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1_book;

import java.util.Scanner;

/**
 *
 * @author emreduman
 */
public class Assignment1_Book {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("From Default Constructor:");
        Book book1=new Book();
        System.out.println(book1.toString());
        System.out.println(book1.getPrice());
        
        System.out.println("\nFrom Argument Constructor:");
        Book book2=new Book("Object",20,60.5);
        System.out.println(book2.toString());
        System.out.println(book2.getPrice());

        Scanner scan=new Scanner(System.in);
        System.out.print("\nEnter a Book Name:"); String Name=scan.nextLine();
        System.out.print("Enter a Quantity:");    int Quantity=scan.nextInt();
        System.out.print("Enter a Price:");       double Price=scan.nextDouble();
        System.out.print("<------------------->\n"); 
        Book test1=new Book(Name,Quantity,Price);
        System.out.println(test1.toString());
        System.out.println(test1.getPrice());
      
        

    }
    
}

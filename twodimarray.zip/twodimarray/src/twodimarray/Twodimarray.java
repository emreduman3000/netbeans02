/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twodimarray;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Twodimarray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        int[][] list={{1,2,3},{4,5,6},{7,8,9}};
//        System.out.println("list[0][2]="+list[0][2]);
//        System.out.println("list[2][1]="+list[2][1]);
          Scanner input=new Scanner(System.in);
          int[][] list=new int[2][3]; //first [] is for raw and second [] for column
          int total=0;
          System.out.println("enter any value to store in array");
          for(int i=0;i<list.length;i++) //this loop is for raw
          {
              for(int j=0;j<list[i].length;j++) //each raw how many column
              {
                  list[i][j]=input.nextInt();
                  total=total+list[i][j];
              }
          }
          for(int i=0;i<list.length;i++) //this loop is for raw
          {
              for(int j=0;j<list[i].length;j++) //each raw how many column
              {
                  System.out.println("list["+i+"]["+j+"]="+list[i][j]);
              }
          }
          System.out.println("total="+total);
    }
    
}

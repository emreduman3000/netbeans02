/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w2testcircle;

/**
 *
 * @author kantaria
 */
public class Cylinder extends Circle  //Cylinder is subclass and Circle is superclass
{
    public double height;
    
    public double areaCylinder()
    {
        return (2*3.14*radius*height)+(2*areaCircle());
    }
}
















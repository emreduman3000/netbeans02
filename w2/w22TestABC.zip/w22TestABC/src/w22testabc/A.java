/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w22testabc;

/**
 *
 * @author kantaria
 */
public class A {
    
    public void show()
    {
        System.out.println("this is class A method");
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w22testabc;

/**
 *
 * @author kantaria
 */
public class W22TestABC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        A a1=new B();
        a1.show();
        
        A a2=new C();
        a2.show();
        
        B b1=new C();
        b1.show(); 
        
        
    }
    
}

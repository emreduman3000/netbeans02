/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w22overriding;

/**
 *
 * @author kantaria
 */
public class Square {
    private double side;
    public Square(double side)
    {
        this.side=side;
    }
    public void area()
    {
        double t=side*side;
        System.out.println("side = "+side);
        System.out.println("area of square = "+t);
    }
}

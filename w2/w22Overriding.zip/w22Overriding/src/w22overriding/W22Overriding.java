/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w22overriding;

import java.util.Scanner;

/**
 *
 * @author kantaria
 */
public class W22Overriding {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        System.out.println("enter side value");
        double s=sc.nextDouble();
        System.out.println("enter height value");
        double h=sc.nextDouble();
        System.out.println("enter width value");
        double w=sc.nextDouble();
        Rectangle r1=new Rectangle(s,h,w);
        r1.area();
        
        Square s1=new Rectangle(5,6,7);
        s1.area(); //calles subclass version of method
    }
    
}

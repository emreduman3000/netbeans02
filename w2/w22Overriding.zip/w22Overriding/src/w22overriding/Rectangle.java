/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w22overriding;

/**
 *
 * @author kantaria
 */
public class Rectangle extends Square
{
    private double height,width;
    public Rectangle(double side,double height,double width)
    {
       super(side); 
       this.height=height;
       this.width=width;
    }
    public void area()
    {
       super.area(); //calles superclass area() method
       double t=height*width;
       System.out.println("heigth="+height+" width="+width);
       System.out.println("area of rectangle="+t);
    }
}

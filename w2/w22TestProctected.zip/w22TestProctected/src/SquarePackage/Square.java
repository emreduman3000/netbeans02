/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SquarePackage;

/**
 *
 * @author kantaria
 */
public class Square 
{
    protected double side;
    public double a;
    private double b;
    double c; //default modifire
    public Square(double side)
    {
        this.side=side;
    }
    public double areaSquare()
    {
        return side*side;
    }  
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w22testproctected;
import SquarePackage.Square;
/**
 *
 * @author kantaria
 */
public class Cube extends Square
{
    int id; //default modifier
    public Cube(double side)
    {
        super(side);
    }
    public double areaCube()
    {
        return 6*areaSquare();
    }
    public double volumeCube()
    {
        return side*side*side;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w22testproctected;

/**
 *
 * @author kantaria
 */
public class W22TestProctected {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Cube c1=new Cube(2.5);
        System.out.println("area of square="+c1.areaSquare());
        System.out.println("area of cube="+c1.areaCube());
        System.out.println("volume of cube="+c1.volumeCube());
        
        //c1.side=4;
        c1.a=10;  //public
        System.out.println("a="+c1.a);
        
        //c1.b=5;
        //c1.c=7;
        
        c1.id=101; 
        System.out.println("id="+c1.id);
    }
    
}

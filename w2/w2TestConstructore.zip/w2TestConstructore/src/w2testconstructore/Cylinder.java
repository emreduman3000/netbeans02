/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w2testconstructore;

/**
 *
 * @author kantaria
 */
public class Cylinder extends Circle
{
    private double height;
    public Cylinder() //no argument constructore
    {
        super(); //to call superclass no argument constructore
        height=5.5;
    }
    public Cylinder(double radius,double height)
    {
        super(radius); //calls super class argument constructore
        this.height=height;
    }
    public double getHeight()
    {
        return height;
    }
    public double areaCylinder()
    {
        return (2*3.14*getRadius()*height)+(2*areaCircle());
    }
    public String toString() //to call super class method super.toString()
    {
        return super.toString()+" height="+height+" area of cylinder= "+areaCylinder();
    }
}














/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w2testconstructore;

import java.util.Scanner;

/**
 *
 * @author kantaria
 */
public class W2TestConstructore {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner input=new Scanner(System.in);
        Cylinder cy1=new Cylinder(); //to call no argument constructore
        
//        System.out.println("radius = "+cy1.getRadius());        
//        System.out.println(cy1.toString());
//        System.out.println("height = "+cy1.getHeight());
//        System.out.println("area of cylinder = "+cy1.areaCylinder());

          System.out.println(cy1.toString());
          
          System.out.println("enter any value for radius");
          double r=input.nextDouble();
          System.out.println("enter any value for height");
          double h=input.nextDouble();
          
          Cylinder cy2=new Cylinder(r,h); //callilng argument constructore
          System.out.println(cy2.toString());
          
    }
    
}


package vegetable;

/** This class +++Insert Description Here+++
 *
 * @author Megha Patel
 */
public class Tomato extends Vegetable {

    public Tomato()
    {
        super("Tomato","Yellow");
    }
    @Override
    public boolean isTasty() {
        return false;
    }

}

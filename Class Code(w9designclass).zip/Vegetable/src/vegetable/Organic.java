/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vegetable;

/**
 *
 * @author Megha, Winter 2020
 */
public interface Organic {
    public static final boolean PESTISIDES=false;
    public abstract void growMethod();
    public abstract void growDuration();
    
}

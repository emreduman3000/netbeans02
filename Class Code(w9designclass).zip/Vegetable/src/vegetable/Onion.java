
package vegetable;

/** This class +++Insert Description Here+++
 *
 * @author Megha Patel
 */
public class Onion extends Vegetable{

    public Onion()
    {
        super("Onion","Red");
    }
    @Override
    public boolean isTasty() {
        return false;
    }
    
    
}

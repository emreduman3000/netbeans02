
package vegetable;

/** This class +++Insert Description Here+++
 *
 * @author Megha Patel
 */
public class Potato extends Vegetable implements Organic {

    public Potato()
    {
        super("Potato","White");
        
    }
    @Override
    public boolean isTasty() {
       return true;
    }

    @Override
    public void growMethod() {
        
    }

    @Override
    public void growDuration() {
     
    }

}

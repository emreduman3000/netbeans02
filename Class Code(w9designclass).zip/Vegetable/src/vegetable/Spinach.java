
package vegetable;

/** This class +++Insert Description Here+++
 *
 * @author Megha Patel
 */
public class Spinach extends Vegetable {

    public Spinach()
    {
        super("Spinach","Green");
    }
    @Override
    public boolean isTasty() {
            return true;
    }

}

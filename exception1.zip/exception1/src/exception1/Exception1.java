/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exception1;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Exception1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
        System.out.println("enter two integer number");
        int a=input.nextInt();
        int b=input.nextInt();
        int c=division(a,b);
        System.out.println("division c="+c);
//        if(b>0)
//            System.out.println("a/b="+(a/b));
//        else
//            System.out.println("divisor can not be zero");        
    }
    public static int division(int a,int b)
    {
        if(b==0)
        {
            System.out.println("divisior can not be zero");
            System.exit(0);
        }
        return (a/b);
    }
    
}

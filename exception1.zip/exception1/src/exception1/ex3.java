/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exception1;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class ex3 {
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
        System.out.println("enter two integer number");
        int a=input.nextInt();
        int b=input.nextInt();
        try
        {
            int d=check(b);
            System.out.println("b="+b);
            
            int c=division(a,b);
            System.out.println("division c="+c);
        }
        catch(ArithmeticException e)
        {
            System.out.println("integer can not be divide by zero"+e);
        }
        catch(Exception e)
        {
            System.out.println("catch number can not be -ve"+e);
        }
        finally
        {
            System.out.println("this is finally stat");
        }
    } 
    public static int division(int a,int b) throws ArithmeticException
    {
        if(b==0)
            throw new ArithmeticException("divisior can not be zero");
        
        return (a/b);   
    }
    public static int check(int b) throws Exception
    {
        if(b<0)
            throw new ArithmeticException("integer can not be -ve");
        return b;
    }
}

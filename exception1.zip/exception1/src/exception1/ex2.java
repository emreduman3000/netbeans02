/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exception1;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class ex2 {
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
        System.out.println("enter two integer number");
        int a=input.nextInt();
        int b=input.nextInt();
        try
        {
            int c=a/b;
            System.out.println("division="+c);
        }
        catch(ArithmeticException e)
        {
            System.out.println("divisior can not be zero");
        }
    }
}
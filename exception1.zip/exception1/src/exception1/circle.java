/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exception1;

/**
 *
 * @author admin
 */
public class circle {
    private double radius;    
    public circle() 
    {
        this(0.0);
    }
    public circle(double radius) {
        setRadius(radius);
    }
    public void setRadius(double radius) throws IllegalArgumentException
    {
        if(radius>=0)
             this.radius = radius;
        else 
            throw new IllegalArgumentException("radius can not be -ve");
    }
    public double getRadius() {
        return radius;
    }
    public double area()
    {
        return 3.14*radius*radius;
    }  
}

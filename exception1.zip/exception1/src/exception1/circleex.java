/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exception1;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class circleex {
     public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
        try
        {
          circle c1=new circle(2.5); 
          System.out.println("radius="+c1.getRadius()+" area="+c1.area());
          circle c2=new circle(); 
          System.out.println("radius="+c2.getRadius()+" area="+c2.area());
          circle c3=new circle(-3.5); 
          System.out.println("radius="+c1.getRadius()+" area="+c1.area());
        }
        catch(IllegalArgumentException e)
        {
            System.out.println("-ve radius not allowed");
        }
     }
}

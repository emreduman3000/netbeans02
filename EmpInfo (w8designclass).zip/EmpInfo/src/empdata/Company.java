package empdata;

import java.util.*;

public class Company {

	Collection<Employee> Worksfor;
}